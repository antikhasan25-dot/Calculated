package com.example.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.LogEntity
import com.example.data.ParentPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ChildNotificationListenerService : NotificationListenerService() {
    private val tag = "ChildNotifListener"

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName ?: return
        // Skip self-notifications to avoid infinite loops
        if (packageName == applicationContext.packageName) return

        val prefs = ParentPreferencesRepository(applicationContext)
        if (!prefs.isNotificationMonitored()) return

        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return

        val title = extras.getCharSequence("android.title")?.toString() ?: "Notification"
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        if (title.isBlank() && text.isBlank()) return

        Log.d(tag, "Notification captured from $packageName: $title - $text")

        val appName = try {
            val pm = applicationContext.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName
        }

        val db = AppDatabase.getDatabase(applicationContext)
        CoroutineScope(Dispatchers.IO).launch {
            db.logDao().insertLog(
                LogEntity(
                    logType = "NOTIFICATION",
                    title = "Notification from $appName",
                    details = "$title: $text",
                    senderOrApp = appName
                )
            )
        }
    }
}
