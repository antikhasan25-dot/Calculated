package com.example.service

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.data.AppDatabase
import com.example.data.LogEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ChildDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(context, "Parental Device Protection Activated", Toast.LENGTH_SHORT).show()
        logEvent(context, "DEVICE_ADMIN", "Device Admin Activated", "Official parental control management protection enabled on device.")
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Toast.makeText(context, "Parental Device Protection Deactivated", Toast.LENGTH_SHORT).show()
        logEvent(context, "DEVICE_ADMIN", "Device Admin Disabled", "Parental control device protection was deactivated.")
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
        logEvent(context, "SECURITY", "Password Attempt Failed", "An incorrect device lock code attempt was detected.")
    }

    private fun logEvent(context: Context, type: String, title: String, details: String) {
        val db = AppDatabase.getDatabase(context)
        CoroutineScope(Dispatchers.IO).launch {
            db.logDao().insertLog(
                LogEntity(
                    logType = type,
                    title = title,
                    details = details,
                    senderOrApp = "Device Policy Manager"
                )
            )
        }
    }
}
