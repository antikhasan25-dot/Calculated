package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.CallLog
import android.provider.Telephony
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.AppDatabase
import com.example.data.FirebaseSyncManager
import com.example.data.LogEntity
import com.example.data.ParentPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class SafetyMonitoringService : Service() {
    private val tag = "SafetyMonitoringService"
    private val channelId = "child_safety_monitoring_channel"
    private val notificationId = 1001

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private var smsObserver: ContentObserver? = null
    private var callLogObserver: ContentObserver? = null

    private lateinit var db: AppDatabase
    private lateinit var prefs: ParentPreferencesRepository
    private lateinit var syncManager: FirebaseSyncManager

    override fun onCreate() {
        super.onCreate()
        db = AppDatabase.getDatabase(applicationContext)
        prefs = ParentPreferencesRepository(applicationContext)
        syncManager = FirebaseSyncManager(applicationContext, db.logDao(), prefs)

        createNotificationChannel()
        startForeground(notificationId, createNotification())

        registerObservers()
        startPeriodicSync()

        logServiceEvent("Service Started", "Safety Monitoring Foreground Service initialized.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerObservers() {
        val handler = Handler(Looper.getMainLooper())

        // SMS Observer
        try {
            smsObserver = object : ContentObserver(handler) {
                override fun onChange(selfChange: Boolean, uri: Uri?) {
                    super.onChange(selfChange, uri)
                    if (prefs.isSmsMonitored()) {
                        scanLatestSms()
                    }
                }
            }
            contentResolver.registerContentObserver(
                Uri.parse("content://sms"),
                true,
                smsObserver!!
            )
        } catch (e: Exception) {
            Log.e(tag, "Failed to register SMS ContentObserver", e)
        }

        // Call Log Observer
        try {
            callLogObserver = object : ContentObserver(handler) {
                override fun onChange(selfChange: Boolean, uri: Uri?) {
                    super.onChange(selfChange, uri)
                    if (prefs.isCallMonitored()) {
                        scanLatestCallLog()
                    }
                }
            }
            contentResolver.registerContentObserver(
                CallLog.Calls.CONTENT_URI,
                true,
                callLogObserver!!
            )
        } catch (e: Exception) {
            Log.e(tag, "Failed to register CallLog ContentObserver", e)
        }
    }

    private fun scanLatestSms() {
        serviceScope.launch {
            try {
                val cursor = contentResolver.query(
                    Telephony.Sms.CONTENT_URI,
                    arrayOf(Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
                    null, null, "${Telephony.Sms.DATE} DESC LIMIT 1"
                )
                cursor?.use {
                    if (it.moveToFirst()) {
                        val address = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)) ?: "Unknown"
                        val body = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.BODY)) ?: ""
                        val type = it.getInt(it.getColumnIndexOrThrow(Telephony.Sms.TYPE))
                        val smsTypeStr = if (type == Telephony.Sms.MESSAGE_TYPE_INBOX) "Received SMS" else "Sent SMS"

                        db.logDao().insertLog(
                            LogEntity(
                                logType = "SMS",
                                title = "$smsTypeStr from $address",
                                details = body,
                                senderOrApp = address
                            )
                        )
                        syncManager.syncLogsToFirebase()
                    }
                }
            } catch (e: SecurityException) {
                Log.w(tag, "SMS permission not granted to read SMS logs.")
            } catch (e: Exception) {
                Log.e(tag, "Error reading SMS log", e)
            }
        }
    }

    private fun scanLatestCallLog() {
        serviceScope.launch {
            try {
                val cursor = contentResolver.query(
                    CallLog.Calls.CONTENT_URI,
                    arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DURATION, CallLog.Calls.DATE),
                    null, null, "${CallLog.Calls.DATE} DESC LIMIT 1"
                )
                cursor?.use {
                    if (it.moveToFirst()) {
                        val number = it.getString(it.getColumnIndexOrThrow(CallLog.Calls.NUMBER)) ?: "Unknown"
                        val duration = it.getInt(it.getColumnIndexOrThrow(CallLog.Calls.DURATION))
                        val callType = it.getInt(it.getColumnIndexOrThrow(CallLog.Calls.TYPE))
                        val typeStr = when (callType) {
                            CallLog.Calls.INCOMING_TYPE -> "Incoming Call"
                            CallLog.Calls.OUTGOING_TYPE -> "Outgoing Call"
                            CallLog.Calls.MISSED_TYPE -> "Missed Call"
                            else -> "Call Event"
                        }

                        db.logDao().insertLog(
                            LogEntity(
                                logType = "CALL",
                                title = "$typeStr: $number",
                                details = "Duration: ${duration}s",
                                senderOrApp = number
                            )
                        )
                        syncManager.syncLogsToFirebase()
                    }
                }
            } catch (e: SecurityException) {
                Log.w(tag, "Call Log permission not granted.")
            } catch (e: Exception) {
                Log.e(tag, "Error reading Call log", e)
            }
        }
    }

    private fun startPeriodicSync() {
        serviceScope.launch {
            while (isActive) {
                delay(30_000L) // Auto sync every 30s
                if (prefs.isServiceActive()) {
                    syncManager.syncLogsToFirebase()
                }
            }
        }
    }

    private fun logServiceEvent(title: String, details: String) {
        serviceScope.launch {
            db.logDao().insertLog(
                LogEntity(
                    logType = "SYSTEM",
                    title = title,
                    details = details,
                    senderOrApp = "Safety Service"
                )
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Child Safety Protection",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors safety activity and syncs logs to parent portal."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Child Protection Active")
            .setContentText("Transparent parental safety service is monitoring this device.")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        smsObserver?.let { contentResolver.unregisterContentObserver(it) }
        callLogObserver?.let { contentResolver.unregisterContentObserver(it) }
        logServiceEvent("Service Stopped", "Safety Monitoring Service terminated.")
    }
}
