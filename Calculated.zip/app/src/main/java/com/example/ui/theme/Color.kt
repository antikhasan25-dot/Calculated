package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Theme Palette
val SleekBg = Color(0xFFF7F9FC)
val SleekCard = Color(0xFFFFFFFF)
val SleekBorder = Color(0xFFF1F5F9)

val SleekBluePrimary = Color(0xFF2563EB)
val SleekBlueSecondary = Color(0xFF1D4ED8)
val SleekBlueContainer = Color(0xFFEFF6FF)

val SleekDarkBtn = Color(0xFF0F172A)
val SleekTextPrimary = Color(0xFF0F172A)
val SleekTextSecondary = Color(0xFF64748B)
val SleekTextMuted = Color(0xFF94A3B8)

val SleekGreenBg = Color(0xFFF0FDF4)
val SleekGreenText = Color(0xFF15803D)
val SleekGreenDot = Color(0xFF22C55E)

val SleekRedBg = Color(0xFFFEF2F2)
val SleekRedText = Color(0xFFB91C1C)

// Dark Theme Variants
val SurfaceDark = Color(0xFF0F172A)
val CardSurfaceDark = Color(0xFF1E293B)
