package com.example.ui

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.ChildDeviceAdminReceiver
import com.example.ui.theme.SleekBg
import com.example.ui.theme.SleekBlueContainer
import com.example.ui.theme.SleekBluePrimary
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekCard
import com.example.ui.theme.SleekDarkBtn
import com.example.ui.theme.SleekGreenBg
import com.example.ui.theme.SleekGreenText
import com.example.ui.theme.SleekRedBg
import com.example.ui.theme.SleekRedText
import com.example.ui.theme.SleekTextMuted
import com.example.ui.theme.SleekTextPrimary
import com.example.ui.theme.SleekTextSecondary
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentSetupScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val parentUid by viewModel.parentUid.collectAsState()
    val parentEmail by viewModel.parentEmail.collectAsState()
    val deviceId by viewModel.deviceId.collectAsState()
    val parentPin by viewModel.parentPin.collectAsState()
    
    val isSmsMonitored by viewModel.isSmsMonitored.collectAsState()
    val isCallMonitored by viewModel.isCallMonitored.collectAsState()
    val isServiceActive by viewModel.isServiceActive.collectAsState()
    val isDeviceAdminActive by viewModel.isDeviceAdminActive.collectAsState()
    val isNotifListenerEnabled by viewModel.isNotifListenerEnabled.collectAsState()

    val syncStatus by viewModel.syncStatus.collectAsState()
    val authStatus by viewModel.authStatus.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()

    var emailInput by remember { mutableStateOf(parentEmail) }
    var passwordInput by remember { mutableStateOf("") }
    var newPinInput by remember { mutableStateOf("") }
    var showPinChangeSuccess by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = SleekBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Parent Setup Portal",
                        fontWeight = FontWeight.Bold,
                        color = SleekTextPrimary
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("setup_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Dashboard",
                            tint = SleekTextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.lockParentSettings(); onNavigateBack() },
                        modifier = Modifier.testTag("lock_setup_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock Setup",
                            tint = SleekBluePrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SleekCard
                ),
                modifier = Modifier.border(1.dp, SleekBorder)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // 1. Firebase Authentication Section
            Card(
                colors = CardDefaults.cardColors(containerColor = SleekCard),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SleekBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SleekBlueContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Firebase Auth",
                                tint = SleekBluePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Firebase Parent Authentication",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SleekTextPrimary
                            )
                            Text(
                                text = "Link child client device to parent Account UID",
                                style = MaterialTheme.typography.bodySmall,
                                color = SleekTextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (parentUid.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(SleekGreenBg)
                                .padding(14.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Connected",
                                        tint = SleekGreenText,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Account Linked & Authenticated",
                                        fontWeight = FontWeight.Bold,
                                        color = SleekGreenText,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Parent Email: $parentEmail",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SleekTextPrimary
                                )
                                Text(
                                    text = "Account UID: $parentUid",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SleekBluePrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = { viewModel.logoutParent() },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("firebase_logout_btn")
                        ) {
                            Text("Sign Out Parent Account", color = SleekRedText)
                        }
                    } else {
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Parent Email") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SleekBluePrimary,
                                unfocusedBorderColor = SleekBorder
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("parent_email_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Password") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SleekBluePrimary,
                                unfocusedBorderColor = SleekBorder
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("parent_pass_input")
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        if (isAuthLoading) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(color = SleekBluePrimary)
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.loginWithFirebase(emailInput, passwordInput) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SleekBluePrimary),
                                    modifier = Modifier.weight(1f).testTag("firebase_login_btn"),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Log In", fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.registerWithFirebase(emailInput, passwordInput) },
                                    modifier = Modifier.weight(1f).testTag("firebase_register_btn"),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Register", color = SleekBluePrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (authStatus != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = authStatus!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (authStatus!!.contains("Success") || authStatus!!.contains("Created")) SleekGreenText else SleekRedText
                        )
                    }
                }
            }

            // 2. Realtime Database Node
            Card(
                colors = CardDefaults.cardColors(containerColor = SleekCard),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SleekBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SleekBlueContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = "Sync Node",
                                tint = SleekBluePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Firebase Realtime Node",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Realtime logs stream location:",
                        style = MaterialTheme.typography.bodySmall,
                        color = SleekTextMuted
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    val nodePath = if (parentUid.isNotEmpty()) {
                        "/parents/$parentUid/devices/$deviceId/activity_logs"
                    } else {
                        "/parents/{PARENT_UID}/devices/$deviceId/activity_logs"
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SleekBg)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = nodePath,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SleekBluePrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.triggerManualSync() },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekDarkBtn),
                        modifier = Modifier.fillMaxWidth().testTag("force_sync_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Sync", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Force Sync Logs Now", fontWeight = FontWeight.SemiBold)
                    }

                    if (syncStatus.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = syncStatus,
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextMuted
                        )
                    }
                }
            }

            // 3. Device Protection (DeviceAdminReceiver)
            Card(
                colors = CardDefaults.cardColors(containerColor = SleekCard),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SleekBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SleekBlueContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Device Protection",
                                tint = SleekBluePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Device Protection Policy",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SleekTextPrimary
                            )
                            Text(
                                text = "Official Android DeviceAdminReceiver policy",
                                style = MaterialTheme.typography.bodySmall,
                                color = SleekTextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isDeviceAdminActive) "Device Protection Active" else "Device Admin Deactivated",
                                fontWeight = FontWeight.Bold,
                                color = if (isDeviceAdminActive) SleekGreenText else SleekRedText
                            )
                            Text(
                                text = "Prevents uninstallation & supports remote lock",
                                style = MaterialTheme.typography.bodySmall,
                                color = SleekTextMuted
                            )
                        }

                        Button(
                            onClick = {
                                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                    putExtra(
                                        DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                                        ComponentName(context, ChildDeviceAdminReceiver::class.java)
                                    )
                                    putExtra(
                                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                        "Child Guardian requires Device Admin to enforce parental device security policies."
                                    )
                                }
                                (context as? Activity)?.startActivity(intent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SleekBluePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("device_admin_toggle_btn")
                        ) {
                            Text(if (isDeviceAdminActive) "Manage Admin" else "Activate Admin", fontSize = 12.sp)
                        }
                    }

                    if (isDeviceAdminActive) {
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { viewModel.lockDeviceNow(context) },
                            modifier = Modifier.fillMaxWidth().testTag("lock_device_now_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = "Lock", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Test Remote Lock Now")
                        }
                    }
                }
            }

            // 4. Safety Monitoring Service Switches
            Card(
                colors = CardDefaults.cardColors(containerColor = SleekCard),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SleekBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Safety Service Monitoring Controls",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SleekTextPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Foreground Service Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Foreground Safety Service", fontWeight = FontWeight.Bold, color = SleekTextPrimary)
                            Text("Runs persistent background protection", style = MaterialTheme.typography.bodySmall, color = SleekTextMuted)
                        }
                        Switch(
                            checked = isServiceActive,
                            onCheckedChange = { viewModel.toggleServiceActive(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SleekBluePrimary),
                            modifier = Modifier.testTag("toggle_fg_service")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // SMS Monitor Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Sms, contentDescription = "SMS", tint = SleekBluePrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("SMS Monitoring", fontWeight = FontWeight.Bold, color = SleekTextPrimary)
                            }
                            Text("Record incoming & outgoing SMS logs", style = MaterialTheme.typography.bodySmall, color = SleekTextMuted)
                        }
                        Switch(
                            checked = isSmsMonitored,
                            onCheckedChange = { viewModel.toggleSmsMonitored(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SleekBluePrimary),
                            modifier = Modifier.testTag("toggle_sms_monitor")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Call Log Monitor Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PhoneInTalk, contentDescription = "Call", tint = SleekBluePrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Call Log Monitoring", fontWeight = FontWeight.Bold, color = SleekTextPrimary)
                            }
                            Text("Record call history logs", style = MaterialTheme.typography.bodySmall, color = SleekTextMuted)
                        }
                        Switch(
                            checked = isCallMonitored,
                            onCheckedChange = { viewModel.toggleCallMonitored(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SleekBluePrimary),
                            modifier = Modifier.testTag("toggle_call_monitor")
                        )
                    }
                }
            }

            // 5. Parent Security PIN Modification
            Card(
                colors = CardDefaults.cardColors(containerColor = SleekCard),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SleekBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SleekBlueContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = "PIN Settings",
                                tint = SleekBluePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Security PIN Settings",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Current Security PIN: $parentPin",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = SleekTextPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newPinInput,
                        onValueChange = { if (it.length <= 8) newPinInput = it },
                        label = { Text("New Security PIN") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SleekBluePrimary,
                            unfocusedBorderColor = SleekBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("new_pin_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (newPinInput.length >= 4) {
                                viewModel.updateParentPin(newPinInput)
                                newPinInput = ""
                                showPinChangeSuccess = true
                            }
                        },
                        enabled = newPinInput.length >= 4,
                        colors = ButtonDefaults.buttonColors(containerColor = SleekBluePrimary),
                        modifier = Modifier.fillMaxWidth().testTag("save_new_pin_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Update Parent Security PIN", fontWeight = FontWeight.Bold)
                    }

                    if (showPinChangeSuccess) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Security PIN updated successfully!",
                            color = SleekGreenText,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
