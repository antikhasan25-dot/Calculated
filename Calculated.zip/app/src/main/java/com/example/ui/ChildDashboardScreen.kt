package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LogEntity
import com.example.ui.theme.SleekBg
import com.example.ui.theme.SleekBlueContainer
import com.example.ui.theme.SleekBluePrimary
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekCard
import com.example.ui.theme.SleekDarkBtn
import com.example.ui.theme.SleekGreenBg
import com.example.ui.theme.SleekGreenDot
import com.example.ui.theme.SleekGreenText
import com.example.ui.theme.SleekRedBg
import com.example.ui.theme.SleekRedText
import com.example.ui.theme.SleekTextMuted
import com.example.ui.theme.SleekTextPrimary
import com.example.ui.theme.SleekTextSecondary
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChildDashboardScreen(
    viewModel: MainViewModel,
    onOpenSetupClicked: () -> Unit,
    onRequestSmsPermission: () -> Unit,
    onRequestCallLogPermission: () -> Unit,
    onRequestNotifPermission: () -> Unit,
    onRequestNotifListener: () -> Unit,
    onRequestDeviceAdmin: () -> Unit
) {
    val logs by viewModel.allLogs.collectAsState(initial = emptyList())
    val totalCount by viewModel.logCount.collectAsState(initial = 0)
    
    val parentUid by viewModel.parentUid.collectAsState()
    val isServiceActive by viewModel.isServiceActive.collectAsState()
    val isDeviceAdminActive by viewModel.isDeviceAdminActive.collectAsState()
    val isNotifListenerEnabled by viewModel.isNotifListenerEnabled.collectAsState()
    
    val hasSmsPerm by viewModel.hasSmsPerm.collectAsState()
    val hasCallLogPerm by viewModel.hasCallLogPerm.collectAsState()
    
    val lastSyncTime by viewModel.lastSyncTime.collectAsState()

    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredLogs = remember(logs, selectedFilter) {
        when (selectedFilter) {
            "SMS" -> logs.filter { it.logType == "SMS" }
            "CALL" -> logs.filter { it.logType == "CALL" }
            "NOTIF" -> logs.filter { it.logType == "NOTIFICATION" }
            "ADMIN" -> logs.filter { it.logType == "DEVICE_ADMIN" || it.logType == "SECURITY" }
            else -> logs
        }
    }

    Scaffold(
        containerColor = SleekBg,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(SleekBluePrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "S",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 20.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "SafeStep Child",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SleekTextPrimary
                            )
                            Text(
                                text = "Transparent Safety Client",
                                style = MaterialTheme.typography.labelSmall,
                                color = SleekTextMuted
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.triggerManualSync() },
                        modifier = Modifier.testTag("dashboard_sync_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Manual Sync",
                            tint = SleekTextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SleekCard
                ),
                modifier = Modifier.border(1.dp, SleekBorder)
            )
        },
        bottomBar = {
            // Sleek Bottom Control Bar
            Surface(
                color = SleekCard,
                tonalElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SleekBorder, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (parentUid.isNotEmpty()) "Target Account: ${parentUid.take(8)}..." else "Target Account: Unlinked",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SleekTextMuted
                        )
                        Text(
                            text = "Firebase Realtime",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SleekTextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onOpenSetupClicked,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekDarkBtn,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("open_parent_setup_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Parental Setup Access",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // 1. Sleek Active Service Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekCard),
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SleekBorder, RoundedCornerShape(24.dp))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "SERVICE STATUS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = SleekBluePrimary,
                                    letterSpacing = 1.2.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isServiceActive) "Monitoring Active" else "Monitoring Paused",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SleekTextPrimary
                                )
                            }

                            // Green / Red Status Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(if (isServiceActive) SleekGreenBg else SleekRedBg)
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(if (isServiceActive) SleekGreenDot else SleekRedText)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isServiceActive) "SECURE" else "PAUSED",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isServiceActive) SleekGreenText else SleekRedText
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Stat 1: Last Sync
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(SleekBg)
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text(
                                        text = "LAST SYNC",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SleekTextMuted
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    val timeStr = if (lastSyncTime > 0) {
                                        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(lastSyncTime))
                                    } else "Never"
                                    Text(
                                        text = timeStr,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SleekTextPrimary
                                    )
                                }
                            }

                            // Stat 2: Synced Logs
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(SleekBg)
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text(
                                        text = "SYNCED LOGS",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SleekTextMuted
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "$totalCount Items",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SleekTextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2. System Permissions Section
            item {
                Column {
                    Text(
                        text = "SYSTEM PERMISSIONS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = SleekTextMuted,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SleekPermissionRow(
                            title = "SMS Monitoring",
                            description = if (hasSmsPerm) "Permission granted via READ_SMS" else "Tap to grant READ_SMS permission",
                            isGranted = hasSmsPerm,
                            icon = Icons.Default.Sms,
                            onClick = onRequestSmsPermission,
                            testTag = "perm_sms_row"
                        )

                        SleekPermissionRow(
                            title = "Call Log Sync",
                            description = if (hasCallLogPerm) "Real-time call activity detection granted" else "Tap to grant READ_CALL_LOG permission",
                            isGranted = hasCallLogPerm,
                            icon = Icons.Default.PhoneInTalk,
                            onClick = onRequestCallLogPermission,
                            testTag = "perm_call_row"
                        )

                        SleekPermissionRow(
                            title = "Notification Listener",
                            description = if (isNotifListenerEnabled) "Active notification listener service" else "Tap to enable in System Settings",
                            isGranted = isNotifListenerEnabled,
                            icon = Icons.Default.Notifications,
                            onClick = onRequestNotifListener,
                            testTag = "perm_notif_row"
                        )

                        SleekPermissionRow(
                            title = "Device Admin",
                            description = if (isDeviceAdminActive) "Protection active and policy locked" else "Tap to enable Device Admin policy",
                            isGranted = isDeviceAdminActive,
                            icon = Icons.Default.AdminPanelSettings,
                            onClick = onRequestDeviceAdmin,
                            testTag = "perm_admin_row"
                        )
                    }
                }
            }

            // 3. Activity Feed Header & Test Generator Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Activity Log Feed",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SleekTextPrimary
                        )
                        Text(
                            text = "Local buffer & Realtime database stream",
                            style = MaterialTheme.typography.labelSmall,
                            color = SleekTextMuted
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = {
                                viewModel.insertTestLog(
                                    type = "SMS",
                                    title = "Incoming Verification SMS",
                                    details = "Safety verification message received from Parent system."
                                )
                            },
                            modifier = Modifier.testTag("add_test_sms_log_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Test Log", tint = SleekBluePrimary)
                        }

                        IconButton(
                            onClick = { viewModel.clearAllLogs() },
                            modifier = Modifier.testTag("clear_logs_btn")
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Logs", tint = SleekTextMuted)
                        }
                    }
                }
            }

            // Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val filterList = listOf("ALL" to "All Logs", "SMS" to "SMS", "CALL" to "Calls", "NOTIF" to "Notifications", "ADMIN" to "Protection")
                    items(filterList) { (key, label) ->
                        val isSelected = selectedFilter == key
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedFilter = key },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            shape = RoundedCornerShape(50),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SleekBluePrimary,
                                selectedLabelColor = Color.White,
                                containerColor = SleekCard,
                                labelColor = SleekTextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = SleekBorder,
                                selectedBorderColor = SleekBluePrimary
                            ),
                            modifier = Modifier.testTag("filter_chip_$key")
                        )
                    }
                }
            }

            // 4. Log Items List
            if (filteredLogs.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SleekCard),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SleekBorder, RoundedCornerShape(20.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(24.dp)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(SleekBlueContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Empty",
                                    tint = SleekBluePrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No Activity Logs Recorded Yet",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall,
                                color = SleekTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Logs appear automatically as device activity occurs. You can also tap '+' to generate sample logs.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SleekTextMuted,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        }
                    }
                }
            } else {
                items(filteredLogs, key = { it.id }) { log ->
                    SleekLogItemCard(log = log)
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun SleekPermissionRow(
    title: String,
    description: String,
    isGranted: Boolean,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SleekBorder, RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (isGranted) SleekBlueContainer else SleekRedBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isGranted) SleekBluePrimary else SleekRedText,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = SleekTextPrimary
                )
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = SleekTextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (isGranted) SleekBlueContainer else SleekRedBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.Check else Icons.Default.Warning,
                    contentDescription = if (isGranted) "Granted" else "Pending",
                    tint = if (isGranted) SleekBluePrimary else SleekRedText,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun SleekLogItemCard(log: LogEntity) {
    val (icon, tint) = when (log.logType) {
        "SMS" -> Icons.Default.Sms to SleekBluePrimary
        "CALL" -> Icons.Default.PhoneInTalk to SleekGreenText
        "NOTIFICATION" -> Icons.Default.Notifications to Color(0xFF7C3AED)
        "DEVICE_ADMIN", "SECURITY" -> Icons.Default.AdminPanelSettings to Color(0xFFDC2626)
        else -> Icons.Default.Info to SleekTextMuted
    }

    val timeFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(log.timestamp))

    Card(
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SleekBorder, RoundedCornerShape(18.dp))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = log.logType,
                    tint = tint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = log.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = SleekTextPrimary,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = timeFormat,
                        fontSize = 11.sp,
                        color = SleekTextMuted
                    )
                }

                if (log.details.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = log.details,
                        fontSize = 12.sp,
                        color = SleekTextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(tint.copy(alpha = 0.08f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = log.logType,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = tint
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (log.isSynced) Icons.Default.CloudDone else Icons.Default.CloudOff,
                            contentDescription = if (log.isSynced) "Synced" else "Local",
                            tint = if (log.isSynced) SleekGreenText else SleekTextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (log.isSynced) "Synced" else "Buffered",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (log.isSynced) SleekGreenText else SleekTextMuted
                        )
                    }
                }
            }
        }
    }
}
