package com.example

import android.app.Application
import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class ChildGuardianApp : Application() {

    override fun onCreate() {
        super.onCreate()
        ensureFirebaseInitialized(this)
    }

    companion object {
        fun ensureFirebaseInitialized(context: Context) {
            if (FirebaseApp.getApps(context).isEmpty()) {
                try {
                    FirebaseApp.initializeApp(context)
                } catch (e: Exception) {
                    Log.w("ChildGuardianApp", "Default FirebaseApp initialization skipped, attempting fallback options", e)
                }

                if (FirebaseApp.getApps(context).isEmpty()) {
                    try {
                        val options = FirebaseOptions.Builder()
                            .setApiKey("AIzaSyMockApiKeyForChildGuardianApp000")
                            .setApplicationId("1:1234567890:android:childguardianapp")
                            .setDatabaseUrl("https://childguardian-default-rtdb.firebaseio.com")
                            .setProjectId("childguardian-app")
                            .build()
                        FirebaseApp.initializeApp(context, options)
                    } catch (e: Exception) {
                        Log.e("ChildGuardianApp", "Failed to initialize fallback FirebaseApp", e)
                    }
                }
            }
        }
    }
}
