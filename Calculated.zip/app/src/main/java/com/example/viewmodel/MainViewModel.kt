package com.example.viewmodel

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ChildGuardianApp
import com.example.data.AppDatabase
import com.example.data.FirebaseSyncManager
import com.example.data.LogEntity
import com.example.data.ParentPreferencesRepository
import com.example.data.SyncResult
import com.example.service.ChildDeviceAdminReceiver
import com.example.service.SafetyMonitoringService
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val logDao = db.logDao()
    private val prefs = ParentPreferencesRepository(application)
    private val syncManager = FirebaseSyncManager(application, logDao, prefs)
    private val auth by lazy {
        ChildGuardianApp.ensureFirebaseInitialized(getApplication())
        FirebaseAuth.getInstance()
    }

    val allLogs = logDao.getAllLogs()
    val logCount = logDao.getLogCount()

    private val _isParentUnlocked = MutableStateFlow(false)
    val isParentUnlocked: StateFlow<Boolean> = _isParentUnlocked.asStateFlow()

    private val _parentUid = MutableStateFlow(prefs.getParentUid())
    val parentUid: StateFlow<String> = _parentUid.asStateFlow()

    private val _parentEmail = MutableStateFlow(prefs.getParentEmail())
    val parentEmail: StateFlow<String> = _parentEmail.asStateFlow()

    private val _deviceId = MutableStateFlow(prefs.getDeviceId())
    val deviceId: StateFlow<String> = _deviceId.asStateFlow()

    private val _deviceName = MutableStateFlow(prefs.getDeviceName())
    val deviceName: StateFlow<String> = _deviceName.asStateFlow()

    private val _parentPin = MutableStateFlow(prefs.getParentPin())
    val parentPin: StateFlow<String> = _parentPin.asStateFlow()

    private val _isSmsMonitored = MutableStateFlow(prefs.isSmsMonitored())
    val isSmsMonitored: StateFlow<Boolean> = _isSmsMonitored.asStateFlow()

    private val _isCallMonitored = MutableStateFlow(prefs.isCallMonitored())
    val isCallMonitored: StateFlow<Boolean> = _isCallMonitored.asStateFlow()

    private val _isNotificationMonitored = MutableStateFlow(prefs.isNotificationMonitored())
    val isNotificationMonitored: StateFlow<Boolean> = _isNotificationMonitored.asStateFlow()

    private val _isServiceActive = MutableStateFlow(prefs.isServiceActive())
    val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

    private val _isDeviceAdminActive = MutableStateFlow(false)
    val isDeviceAdminActive: StateFlow<Boolean> = _isDeviceAdminActive.asStateFlow()

    private val _isNotifListenerEnabled = MutableStateFlow(false)
    val isNotifListenerEnabled: StateFlow<Boolean> = _isNotifListenerEnabled.asStateFlow()

    private val _hasSmsPerm = MutableStateFlow(false)
    val hasSmsPerm: StateFlow<Boolean> = _hasSmsPerm.asStateFlow()

    private val _hasCallLogPerm = MutableStateFlow(false)
    val hasCallLogPerm: StateFlow<Boolean> = _hasCallLogPerm.asStateFlow()

    private val _hasPostNotifPerm = MutableStateFlow(false)
    val hasPostNotifPerm: StateFlow<Boolean> = _hasPostNotifPerm.asStateFlow()

    private val _syncStatus = MutableStateFlow("Idle")
    val syncStatus: StateFlow<String> = _syncStatus.asStateFlow()

    private val _lastSyncTime = MutableStateFlow(prefs.getLastSyncTime())
    val lastSyncTime: StateFlow<Long> = _lastSyncTime.asStateFlow()

    private val _authStatus = MutableStateFlow<String?>(null)
    val authStatus: StateFlow<String?> = _authStatus.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    init {
        checkPermissionsAndStatuses()
        try {
            ChildGuardianApp.ensureFirebaseInitialized(application)
            val currentUser = auth.currentUser
            if (currentUser != null) {
                _parentUid.value = currentUser.uid
                _parentEmail.value = currentUser.email ?: prefs.getParentEmail()
                prefs.setParentUid(currentUser.uid)
                if (!currentUser.email.isNullOrEmpty()) {
                    prefs.setParentEmail(currentUser.email!!)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("MainViewModel", "Firebase Auth init check failed", e)
        }
    }

    fun verifyPin(inputPin: String): Boolean {
        val matches = prefs.verifyPin(inputPin)
        if (matches) {
            _isParentUnlocked.value = true
        }
        return matches
    }

    fun lockParentSettings() {
        _isParentUnlocked.value = false
    }

    fun updateParentPin(newPin: String) {
        prefs.setParentPin(newPin)
        _parentPin.value = newPin
    }

    fun updateDeviceName(name: String) {
        prefs.setDeviceName(name)
        _deviceName.value = name
    }

    fun loginWithFirebase(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _authStatus.value = "Email and Password cannot be empty."
            return
        }
        _isAuthLoading.value = true
        _authStatus.value = null
        auth.signInWithEmailAndPassword(email.trim(), pass)
            .addOnSuccessListener { result ->
                _isAuthLoading.value = false
                val user = result.user
                if (user != null) {
                    _parentUid.value = user.uid
                    _parentEmail.value = user.email ?: email
                    prefs.setParentUid(user.uid)
                    prefs.setParentEmail(user.email ?: email)
                    _authStatus.value = "Firebase Auth Success! UID: ${user.uid}"
                    viewModelScope.launch {
                        insertTestLog("SECURITY", "Parent Logged In", "Parent user ${user.email} authenticated successfully via Firebase.")
                        triggerManualSync()
                    }
                }
            }
            .addOnFailureListener { e ->
                _isAuthLoading.value = false
                _authStatus.value = "Login Failed: ${e.localizedMessage}"
            }
    }

    fun registerWithFirebase(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _authStatus.value = "Email and Password cannot be empty."
            return
        }
        _isAuthLoading.value = true
        _authStatus.value = null
        auth.createUserWithEmailAndPassword(email.trim(), pass)
            .addOnSuccessListener { result ->
                _isAuthLoading.value = false
                val user = result.user
                if (user != null) {
                    _parentUid.value = user.uid
                    _parentEmail.value = user.email ?: email
                    prefs.setParentUid(user.uid)
                    prefs.setParentEmail(user.email ?: email)
                    _authStatus.value = "Account Created! Linked to UID: ${user.uid}"
                    viewModelScope.launch {
                        insertTestLog("SECURITY", "Parent Account Registered", "New parent account created for ${user.email}.")
                        triggerManualSync()
                    }
                }
            }
            .addOnFailureListener { e ->
                _isAuthLoading.value = false
                _authStatus.value = "Registration Failed: ${e.localizedMessage}"
            }
    }

    fun logoutParent() {
        auth.signOut()
        _parentUid.value = ""
        _authStatus.value = "Logged out from Firebase Auth."
    }

    fun toggleSmsMonitored(enabled: Boolean) {
        prefs.setSmsMonitored(enabled)
        _isSmsMonitored.value = enabled
    }

    fun toggleCallMonitored(enabled: Boolean) {
        prefs.setCallMonitored(enabled)
        _isCallMonitored.value = enabled
    }

    fun toggleNotificationMonitored(enabled: Boolean) {
        prefs.setNotificationMonitored(enabled)
        _isNotificationMonitored.value = enabled
    }

    fun toggleServiceActive(enabled: Boolean) {
        prefs.setServiceActive(enabled)
        _isServiceActive.value = enabled
        val context = getApplication<Application>()
        val serviceIntent = Intent(context, SafetyMonitoringService::class.java)
        if (enabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } else {
            context.stopService(serviceIntent)
        }
    }

    fun triggerManualSync() {
        viewModelScope.launch {
            _syncStatus.value = "Syncing with Firebase Database..."
            val result = syncManager.syncLogsToFirebase()
            when (result) {
                is SyncResult.Success -> {
                    _syncStatus.value = result.message
                    _lastSyncTime.value = prefs.getLastSyncTime()
                }
                is SyncResult.Error -> {
                    _syncStatus.value = result.message
                }
            }
        }
    }

    fun insertTestLog(type: String, title: String, details: String) {
        viewModelScope.launch {
            logDao.insertLog(
                LogEntity(
                    logType = type,
                    title = title,
                    details = details,
                    senderOrApp = "Test Event"
                )
            )
        }
    }

    fun clearAllLogs() {
        viewModelScope.launch {
            logDao.clearLogs()
        }
    }

    fun checkPermissionsAndStatuses() {
        val context = getApplication<Application>()

        _hasSmsPerm.value = ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        _hasCallLogPerm.value = ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            _hasPostNotifPerm.value = ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            _hasPostNotifPerm.value = true
        }

        // Check Device Admin status
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(context, ChildDeviceAdminReceiver::class.java)
        _isDeviceAdminActive.value = dpm.isAdminActive(adminComponent)

        // Check Notification Listener status
        val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        _isNotifListenerEnabled.value = flat != null && flat.contains(context.packageName)
    }

    fun lockDeviceNow(context: Context) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(context, ChildDeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(adminComponent)) {
            dpm.lockNow()
            viewModelScope.launch {
                insertTestLog("DEVICE_ADMIN", "Device Screen Locked", "Device was manually locked by parental protection policy.")
            }
        }
    }
}
