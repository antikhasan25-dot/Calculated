package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "activity_logs")
data class LogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val logType: String, // "SMS", "CALL", "NOTIFICATION", "DEVICE_ADMIN", "SECURITY"
    val title: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false,
    val senderOrApp: String = ""
)
