package com.example.data

import android.content.Context
import android.util.Log
import com.example.ChildGuardianApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirebaseSyncManager(
    private val context: Context,
    private val logDao: LogDao,
    private val prefsRepository: ParentPreferencesRepository
) {
    private val tag = "FirebaseSyncManager"

    suspend fun syncLogsToFirebase(): SyncResult = withContext(Dispatchers.IO) {
        val unsynced = logDao.getUnsyncedLogs()
        if (unsynced.isEmpty()) {
            return@withContext SyncResult.Success(0, "All logs are already up to date")
        }

        ChildGuardianApp.ensureFirebaseInitialized(context)

        var parentUid = prefsRepository.getParentUid()
        val authUser = try {
            FirebaseAuth.getInstance().currentUser
        } catch (e: Exception) {
            Log.w(tag, "Failed to retrieve FirebaseAuth currentUser", e)
            null
        }

        if (authUser != null) {
            parentUid = authUser.uid
            prefsRepository.setParentUid(parentUid)
        }

        if (parentUid.isBlank()) {
            return@withContext SyncResult.Error("Parent Account UID not configured. Log in with Firebase Auth in Setup.")
        }

        val deviceId = prefsRepository.getDeviceId()
        val deviceName = prefsRepository.getDeviceName()

        try {
            val database = FirebaseDatabase.getInstance()
            val deviceRef = database.getReference("parents")
                .child(parentUid)
                .child("devices")
                .child(deviceId)

            // Update device metadata
            val deviceMeta = mapOf(
                "deviceName" to deviceName,
                "lastSeen" to System.currentTimeMillis(),
                "serviceActive" to prefsRepository.isServiceActive(),
                "smsMonitored" to prefsRepository.isSmsMonitored(),
                "callMonitored" to prefsRepository.isCallMonitored(),
                "notificationMonitored" to prefsRepository.isNotificationMonitored()
            )
            deviceRef.child("meta").updateChildren(deviceMeta)

            val logsNode = deviceRef.child("activity_logs")
            val syncedIds = mutableListOf<Long>()

            for (log in unsynced) {
                val logMap = mapOf(
                    "id" to log.id,
                    "logType" to log.logType,
                    "title" to log.title,
                    "details" to log.details,
                    "senderOrApp" to log.senderOrApp,
                    "timestamp" to log.timestamp,
                    "deviceId" to deviceId
                )

                val logKey = "log_${log.id}_${log.timestamp}"
                logsNode.child(logKey).setValue(logMap).await()
                syncedIds.add(log.id)
            }

            if (syncedIds.isNotEmpty()) {
                logDao.markLogsSynced(syncedIds)
                val now = System.currentTimeMillis()
                prefsRepository.setLastSyncTime(now)
            }

            SyncResult.Success(syncedIds.size, "Successfully synced ${syncedIds.size} logs to Firebase RTDB node: /parents/$parentUid/devices/$deviceId")
        } catch (e: Exception) {
            Log.e(tag, "Firebase sync failed or offline", e)
            SyncResult.Error("Firebase Sync Notice: ${e.localizedMessage ?: "Offline buffering active"}. Logs saved locally.")
        }
    }
}

sealed class SyncResult {
    data class Success(val count: Int, val message: String) : SyncResult()
    data class Error(val message: String) : SyncResult()
}
