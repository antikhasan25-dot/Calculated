package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: LogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<LogEntity>)

    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<LogEntity>>

    @Query("SELECT * FROM activity_logs WHERE isSynced = 0 ORDER BY timestamp ASC LIMIT 50")
    suspend fun getUnsyncedLogs(): List<LogEntity>

    @Query("UPDATE activity_logs SET isSynced = 1 WHERE id IN (:ids)")
    suspend fun markLogsSynced(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM activity_logs")
    fun getLogCount(): Flow<Int>

    @Query("DELETE FROM activity_logs")
    suspend fun clearLogs()
}
