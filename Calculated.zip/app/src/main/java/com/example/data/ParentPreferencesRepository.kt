package com.example.data

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

class ParentPreferencesRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("parent_child_guardian_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PARENT_UID = "parent_uid"
        private const val KEY_PARENT_EMAIL = "parent_email"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_PARENT_PIN = "parent_pin"
        private const val KEY_SMS_MONITOR = "sms_monitor"
        private const val KEY_CALL_MONITOR = "call_monitor"
        private const val KEY_NOTIF_MONITOR = "notif_monitor"
        private const val KEY_SERVICE_ACTIVE = "service_active"
        private const val KEY_LAST_SYNC_TIME = "last_sync_time"
        private const val KEY_DEVICE_NAME = "device_name"
    }

    init {
        if (getDeviceId().isEmpty()) {
            val newId = "child_dev_" + UUID.randomUUID().toString().take(8)
            prefs.edit().putString(KEY_DEVICE_ID, newId).apply()
        }
        if (getDeviceName().isEmpty()) {
            val name = "${android.os.Build.MANUFACTURER.capitalize()} ${android.os.Build.MODEL}"
            prefs.edit().putString(KEY_DEVICE_NAME, name).apply()
        }
    }

    fun getParentUid(): String = prefs.getString(KEY_PARENT_UID, "") ?: ""
    fun setParentUid(uid: String) {
        prefs.edit().putString(KEY_PARENT_UID, uid).apply()
    }

    fun getParentEmail(): String = prefs.getString(KEY_PARENT_EMAIL, "parent@guardian.app") ?: "parent@guardian.app"
    fun setParentEmail(email: String) {
        prefs.edit().putString(KEY_PARENT_EMAIL, email).apply()
    }

    fun getDeviceId(): String = prefs.getString(KEY_DEVICE_ID, "") ?: ""
    
    fun getDeviceName(): String = prefs.getString(KEY_DEVICE_NAME, "Child Device") ?: "Child Device"
    fun setDeviceName(name: String) {
        prefs.edit().putString(KEY_DEVICE_NAME, name).apply()
    }

    fun getParentPin(): String = prefs.getString(KEY_PARENT_PIN, "1234") ?: "1234"
    fun setParentPin(pin: String) {
        prefs.edit().putString(KEY_PARENT_PIN, pin).apply()
    }

    fun verifyPin(inputPin: String): Boolean = inputPin == getParentPin()

    fun isSmsMonitored(): Boolean = prefs.getBoolean(KEY_SMS_MONITOR, true)
    fun setSmsMonitored(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SMS_MONITOR, enabled).apply()
    }

    fun isCallMonitored(): Boolean = prefs.getBoolean(KEY_CALL_MONITOR, true)
    fun setCallMonitored(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_CALL_MONITOR, enabled).apply()
    }

    fun isNotificationMonitored(): Boolean = prefs.getBoolean(KEY_NOTIF_MONITOR, true)
    fun setNotificationMonitored(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIF_MONITOR, enabled).apply()
    }

    fun isServiceActive(): Boolean = prefs.getBoolean(KEY_SERVICE_ACTIVE, true)
    fun setServiceActive(active: Boolean) {
        prefs.edit().putBoolean(KEY_SERVICE_ACTIVE, active).apply()
    }

    fun getLastSyncTime(): Long = prefs.getLong(KEY_LAST_SYNC_TIME, 0L)
    fun setLastSyncTime(time: Long) {
        prefs.edit().putLong(KEY_LAST_SYNC_TIME, time).apply()
    }
}
