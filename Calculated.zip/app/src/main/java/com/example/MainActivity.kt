package com.example

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.service.ChildDeviceAdminReceiver
import com.example.service.SafetyMonitoringService
import com.example.ui.ChildDashboardScreen
import com.example.ui.ParentSetupScreen
import com.example.ui.PermissionRationaleDialog
import com.example.ui.PinLockDialog
import com.example.ui.theme.ChildGuardianTheme
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ChildGuardianApp.ensureFirebaseInitialized(this)
        enableEdgeToEdge()

        // Auto-start Safety Monitoring Foreground Service if enabled in preferences
        startSafetyServiceIfEnabled()

        setContent {
            ChildGuardianTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainAppContent(viewModel = viewModel)
                }
            }
        }
    }

    private fun startSafetyServiceIfEnabled() {
        val isServiceActive = viewModel.isServiceActive.value
        if (isServiceActive) {
            val serviceIntent = Intent(this, SafetyMonitoringService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkPermissionsAndStatuses()
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val isParentUnlocked by viewModel.isParentUnlocked.collectAsState()
    val parentPin by viewModel.parentPin.collectAsState()

    var currentScreen by remember { mutableStateOf("DASHBOARD") }
    var showPinDialog by remember { mutableStateOf(false) }

    var pendingPermissionType by remember { mutableStateOf<String?>(null) }
    var showRationaleDialog by remember { mutableStateOf(false) }

    // Re-check statuses on lifecycle resume
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.checkPermissionsAndStatuses()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Permission Launchers
    val smsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.checkPermissionsAndStatuses()
        if (isGranted) {
            Toast.makeText(context, "SMS Permission Granted", Toast.LENGTH_SHORT).show()
        }
    }

    val callLogPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.checkPermissionsAndStatuses()
        if (isGranted) {
            Toast.makeText(context, "Call Log Permission Granted", Toast.LENGTH_SHORT).show()
        }
    }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.checkPermissionsAndStatuses()
        if (isGranted) {
            Toast.makeText(context, "Notification Permission Granted", Toast.LENGTH_SHORT).show()
        }
    }

    // Navigation and screens
    if (currentScreen == "SETUP" && isParentUnlocked) {
        ParentSetupScreen(
            viewModel = viewModel,
            onNavigateBack = { currentScreen = "DASHBOARD" }
        )
    } else {
        ChildDashboardScreen(
            viewModel = viewModel,
            onOpenSetupClicked = {
                if (isParentUnlocked) {
                    currentScreen = "SETUP"
                } else {
                    showPinDialog = true
                }
            },
            onRequestSmsPermission = {
                pendingPermissionType = "SMS"
                showRationaleDialog = true
            },
            onRequestCallLogPermission = {
                pendingPermissionType = "CALL"
                showRationaleDialog = true
            },
            onRequestNotifPermission = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pendingPermissionType = "POST_NOTIF"
                    showRationaleDialog = true
                }
            },
            onRequestNotifListener = {
                val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                context.startActivity(intent)
            },
            onRequestDeviceAdmin = {
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(
                        DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                        ComponentName(context, ChildDeviceAdminReceiver::class.java)
                    )
                    putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Child Guardian requires Device Admin to enforce parental control device security policies."
                    )
                }
                (context as? Activity)?.startActivity(intent)
            }
        )
    }

    // PIN Lock Dialog
    if (showPinDialog) {
        PinLockDialog(
            onDismiss = { showPinDialog = false },
            onPinSubmitted = { enteredPin ->
                val success = viewModel.verifyPin(enteredPin)
                if (success) {
                    currentScreen = "SETUP"
                }
                success
            },
            currentPin = parentPin
        )
    }

    // Permission Rationale Dialog
    if (showRationaleDialog && pendingPermissionType != null) {
        val (title, rationale) = when (pendingPermissionType) {
            "SMS" -> "READ_SMS Permission" to "Required to transparently monitor incoming and outgoing SMS activity to ensure child online safety."
            "CALL" -> "READ_CALL_LOG Permission" to "Required to record call log history (incoming, outgoing, missed calls) for parent safety review."
            "POST_NOTIF" -> "Notification Permission" to "Required to display ongoing foreground protection status and safety alerts."
            else -> "System Permission" to "Required for parental control safety functions."
        }

        PermissionRationaleDialog(
            permissionTitle = title,
            permissionRationale = rationale,
            onConfirm = {
                showRationaleDialog = false
                when (pendingPermissionType) {
                    "SMS" -> smsPermissionLauncher.launch(android.Manifest.permission.READ_SMS)
                    "CALL" -> callLogPermissionLauncher.launch(android.Manifest.permission.READ_CALL_LOG)
                    "POST_NOTIF" -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }
                pendingPermissionType = null
            },
            onDismiss = {
                showRationaleDialog = false
                pendingPermissionType = null
            }
        )
    }
}
